//animations like p5 images should be stored in variables
//in order to be displayed during the draw cycle
var ship;
var enemy_ship;
var enemy_ships;
var comet;
var comets;

var bullets;
var asteroid;
var asteroids;
var asteroidIMG;
var bulletIMG;
var enemyIMG;
var cometIMG;



//sounds
var music;
var lazer;

var gameStarted = false;
var gameOver = false;
 

 
// create variable to refer to asteroid
//var asteroid;
// how often do i want asteroid to spawn?
var asteroidSpawn = 200;	// fith of a second
var cometSpawn = 250; //quater second
var enemySpawn = 500;
var lastSpawnTime;	// keep track of the last time spawn happened
var asteroidLastSpawnTime;
var cometLastSpawnTime;
var enemylastSpawnTime;


 
// a few global parameters we can freely adjust
var GRAVITY = 1;
var JUMP = 15;

var score = 0;

var lives = 5;

var starCount =5; //amount of stars
 
//it's advisable (but not necessary) to load the images in the preload function
//of your sketch otherwise they may appear with a little delay
function preload() {
 
	// create a ship sprite and give it an arbitrary starting position,
	// we will change that later
	ship = createSprite();
	
	// give him a couple animation types and specify where the files exist
	ship.addAnimation("running", "ship/asteroids_ship0001.png", "ship/asteroids_ship0007.png");
	ship.addAnimation("jumping", "ship/asteroids_ship0001.png", "ship/asteroids_ship0007.png");
	// he's too big so scale him down to 30%
	ship.scale = 1;
	// he runs too fast so put 6 frames between each image in sprite animation
	ship.animation.frameDelay = 6;

	//asteroid = createSprite();
	asteroidIMG = loadImage("asteroid/asteroid.png");
	bulletIMG = loadImage("bullet/bullet_big.png");
	enemyIMG = loadImage("ship/asteroids_ship_enemy.png");
	cometIMG = loadImage("comet/comet.png");
	

	//asteroid.animation.frameDelay = 6;

	music = loadSound("music/MegamanX7.mp3");
	lazer = loadSound("soundpack1/rifle.wav");

}
 
function setup() {
	createCanvas(windowWidth, windowHeight);


 
	// adjust ship position
	ship.position.x = width / 8;
	ship.position.y = height - 20;


 

 
	// tell the sketch that asteroid will be a 
	// collection of things
	//asteroid = new Group();
	asteroids = new Group();
	bullets = new Group();
	enemy_ships = new Group();
	comets = new Group();
 
	// debug
	// ship.debug = true;
	// ground.debug = true;
 
	// start counting from this moment (for spawns)
	//lastSpawnTime = millis();
	asteroidLastSpawnTime = millis();
	cometLastSpawnTime = millis();
	enemylastSpawnTime = millis();
    music.loop();
 
}
 
function draw() {
	
    if(gameStarted){

		if(!gameOver) {	

			background(0);
	        noStroke();

			//create index
			var i = 0;

			//star background spawn
			while(i<starCount){
				//random scale of grey
				var bri = map(i, 0, starCount, 1 ,255); //brightness
				fill(bri);
				
		        //generate starting point
				var x =random(width);
				var y = random(height);

				//random diameter
				//var d =i/5;
				var d = map(i, 0, starCount, 1 ,20);

				ellipse(x, y,d,d);

		      //increment index i by 1
		      i++;
			}

			textSize(20);
			fill(255);
			text("SCORE:"+score,20,20);
			textSize(20);
			fill(255);
			text("LIVES:"+lives,20,50);
			
		 
			// gravity push down!
			ship.velocity.y += GRAVITY;
		 
			// did ship collide with the singular ground object?
			
		 
			// if jump
			if (keyWentDown("x") || mouseWentDown(LEFT)) {
				ship.changeAnimation("jumping");
				ship.velocity.y = -JUMP;
			}

			 ship.position.y = constrain(mouseY, ship.width/8, height - 20);

			//keyboard controls
			// if (keyWentDown("a")) //a
		    //  ship.position.x -= ship.speed;
		 
		   // if (keyWentDown("d")) //d
		   //   ship.position.x += ship.speed;
		 
		   // if (keyWentDown("w")) //w
		   //   ship.position.y -= ship.speed;
		 
		    //if (keyWentDown("s")) //s
		    //  ship.position.y += ship.speed;
		 
			// spawn asteroid logic
			if(millis() > asteroidLastSpawnTime+ asteroidSpawn) {
				// spawn new obstacle
				asteroid = createSprite(width-10,random(height),10,10);
				asteroid.setCollider("rectangle",0,0,40,80);
		 
				// give it a negative speed to go from right to left
				asteroid.velocity.x = -20;

				asteroid.addImage(asteroidIMG);
				asteroid.life = 80;
				asteroids.add(asteroid);
		 
				// show bounding box
				//newSprite.debug = true;
		 
				// add it to the asteroid group
				//asteroid.add(newSprite);
		 
				// reset timer
				asteroidLastSpawnTime = millis();
			}
	        //comet spawn
			if(millis() > cometLastSpawnTime + cometSpawn) {
				// spawn new obstacle
				comet = createSprite(width-10,random(height),10,10)
				comet.setCollider("rectangle",0,0,40,80);
		 
				// give it a negative speed to go from right to left
				comet.velocity.x = -25;

				comet.addImage(cometIMG);
				comet.life = 80;

				comets.add(comet);
		 
				// show bounding box
				//newSprite.debug = true;
		 
				// add it to the comet group
				//comet.add(newSprite);
		 
				// reset timer
				cometLastSpawnTime = millis();
			}
	        //enemyship spawn
			if(millis() > enemylastSpawnTime + enemySpawn) {
				// spawn new obstacle
				enemy_ship = createSprite(width-10,random(height),10,10)
				enemy_ship.setCollider("rectangle",0,0,40,80);
		 
				// give it a negative speed to go from right to left
				enemy_ship.velocity.x = -30;

				enemy_ship.addImage(enemyIMG);
				enemy_ship.life = 80;
				enemy_ships.add(enemy_ship);
		 
				// show bounding box
				//newSprite.debug = true;
		 
				// add it to the enemy_ship group
				//enemy_ship.add(newSprite);
		 
				// reset timer
				enemylastSpawnTime = millis();
			}
			


			

			if(keyWentDown("z")){
		    
			    //lazer.play(); //sound for lazer lags the game if implemented currently
			    var bullet = createSprite(ship.position.x, ship.position.y);
			    bullet.addImage(bulletIMG);
			   // bullet.setSpeed(10+ship.getSpeed(), ship.rotation);
			    bullet.velocity.x = 15;
			    //bullet.life = 30;
			    bullet.life = 40;
			    bullets.add(bullet);
		    
		    }
		 
		    //if ship hits asteroid call this function 
		    //ship.overlap(asteroids,hitObstacle); 
		    bullets.overlap(asteroids,hitAsteroid);

		    
		    //if ship hits comet call this function 
	        bullets.overlap(comets,hitComet);  

	        //if ship hits enemy ship call this function 
	        bullets.overlap(enemy_ships,hitEnemy);  
		   
		   
		    if(ship.overlap(asteroids,shipContact)){
		       lives--;
		      //die();
		    }

		    if(ship.overlap(comets,shipContact)){
		       lives--;
		      //die();
		    }

		    if(ship.overlap(enemy_ships,shipContact)){
		       lives--;
		      //die();
		    }



		    if(lives==0){
		    	gameOver=true;
		    }
	       
	       

			drawSprites();
		}else {
			// game over...
			background(0);

			// draw end game text
			textAlign(CENTER, CENTER);

			// drop shadow text...
		
			textSize(20);
			fill(0);
			text("GAME OVER YOU \n SCORED " + score + " POINTS", width/2 + 3, height/2 + 3);
			// white text
			textSize(20);
			
			fill(255);
			text("GAME OVER YOU \n SCORED " + score + " POINTS", width/2, height/2);

		}
	}else{

            background(0);
			fill(100);
            rectMode(CENTER);
            rect(width/2,height/2,200,50);
            textAlign(CENTER, CENTER);
            textSize(20);
            fill(0);
            text("START GAME",width/2,height/2);

            textAlign(CENTER, CENTER);
            textSize(150);
            fill(255);
            text("Asteroid Run",width/2,height/8);

            textAlign(CENTER, CENTER);
            textSize(40);
            fill(255);
            text("Press 'z' to shoot and use the mouse to move",width/2,height/3);


            if(mouseX>(width/2)-100){
              if(mouseX < width/2 +100){

                if(mouseY > height/2-25){
              
                  if(mouseY <height/2 + 25){
                    if(mouseIsPressed){
                      gameStarted = true;
                    }
                  }
                }
              
              }
            }   

		}


}

//provide 2 arguements
//1: big fish
//2: little fish

function hitAsteroid(bullet, asteroid){
       //console.log("game oveR");

       asteroid.remove();
       
       score++;


}

function hitComet(bullet, comet){
       //console.log("game oveR");

       comet.remove();
       
       score+=2;


}

function hitEnemy(bullet, enemy){
       //console.log("game oveR");

       enemy.remove();
       
       score+=10;


}



function shipContact(ship, collectable){
       //console.log("game oveR");

       collectable.remove();
       
       


}

function die() {
  updateSprites(false);
  gameOver = true;
  fill(255,0,0);
  text("Game Over",width/2,height/2,10,10);   
}
