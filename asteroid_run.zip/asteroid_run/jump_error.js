//Creating animations

//animations like p5 images should be stored in variables
//in order to be displayed during the draw cycle
var bernie;

// singular collider to stand on
var ground;

//variable to refer to obstabcles
var obstacles;

//how often do I wan obstacles to spawn
var spawnObstaclesInterval = 1000; //1 second
var lastSpawnTime; //keep track of the last spawn time

// a few global parameters we can freely adjust
var GRAVITY = 1;
var JUMP = 15;

//it's advisable (but not necessary) to load the images in the preload function
//of your sketch otherwise they may appear with a little delay
function preload() {

	// create a bernie sprite and give it an arbitrary starting position,
	// we will change that later
	bernie = createSprite();
	// give him a couple animation types and specify where the files exist
	bernie.addAnimation("running", "assets_jump/bernie-walk-0.png", "assets_jump/bernie-walk-3.png");
	bernie.addAnimation("jumping", "assets_jump/bernie-jump.png");
	// he's too big so scale him down to 30%
	bernie.scale = .3;
	// he runs too fast so put 6 frames between each image in sprite animation
	bernie.animation.frameDelay = 6;
}

function setup() {
	createCanvas(windowWidth, windowHeight);

	// adjust bernie position
	bernie.position.x = width / 2;
	bernie.position.y = height - 100;

	// just make a plain old "sprite" for the ground
	// sprites draw from their center, so start at width/2
	ground = createSprite(width / 2, height - 10, width, 10);
    
    //obstacles will be a collection of things 
	obstacles = new Group();

	//debug
	//bernie.debug=true;
	//ground.debug=true;

	lastSpawnTime = millis();

}

function draw() {
	background(80);

	// gravity push down!
	bernie.velocity.y += GRAVITY;
    //did bernie collide with the ground
	if (bernie.collide(ground)) {
		bernie.changeAnimation("running");
		bernie.velocity.y = 0;
	}
    //if jump
	if (keyWentDown("x") || mouseWentDown(LEFT)) {
		bernie.changeAnimation("jumping");
		//bernie.animation.rewind();
		bernie.velocity.y = -JUMP;
	}

	//spawn obstacle logic
	if(millis() > lastSpawnTime + spawnObstacleInterval){
       
       var newSprite = createSprite(width,random(height),20,20);
       
       newSprite.velocity.x = -7;

       new sprite.debug =true;

       obstacles.add(newSprite);

       //reset time
       lastSpawnTime = millis();

	}

	drawSprites();
}
