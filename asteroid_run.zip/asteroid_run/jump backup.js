//animations like p5 images should be stored in variables
//in order to be displayed during the draw cycle
var ship;
var asteroid;
var asteroids;
var asteroidIMG;
 
// singular collider to stand on
var ground;
 
// create variable to refer to asteroid
//var asteroid;
// how often do i want asteroid to spawn?
var spawnObstacleInterval = 1000;	// 1 second
var lastSpawnTime;	// keep track of the last time spawn happened
 
// a few global parameters we can freely adjust
var GRAVITY = 1;
var JUMP = 15;

var score = 0;
 
//it's advisable (but not necessary) to load the images in the preload function
//of your sketch otherwise they may appear with a little delay
function preload() {
 
	// create a ship sprite and give it an arbitrary starting position,
	// we will change that later
	ship = createSprite();
	
	// give him a couple animation types and specify where the files exist
	ship.addAnimation("running", "ship/asteroids_ship0001.png", "ship/asteroids_ship0007.png");
	ship.addAnimation("jumping", "ship/asteroids_ship0001.png", "ship/asteroids_ship0007.png");
	// he's too big so scale him down to 30%
	ship.scale = 3;
	// he runs too fast so put 6 frames between each image in sprite animation
	ship.animation.frameDelay = 6;

	//asteroid = createSprite();
	asteroidIMG = loadImage("asteroid/asteroid1.png");
	//asteroid.animation.frameDelay = 6;

}
 
function setup() {
	createCanvas(windowWidth, windowHeight);
 
	// adjust ship position
	ship.position.x = width / 4;
	ship.position.y = height - 100;


 
	// just make a plain old "sprite" for the ground
	// sprites draw from their center, so start at width/2
	ground = createSprite(width / 2, height - 10, width, 10);
 
	// tell the sketch that asteroid will be a 
	// collection of things
	//asteroid = new Group();
	asteroid = new Group();
 
	// debug
	// ship.debug = true;
	// ground.debug = true;
 
	// start counting from this moment (for spawns)
	lastSpawnTime = millis();
 
}
 
function draw() {
	background(80);
	fill(255,255,0);
	text(score,10,10);
 
	// gravity push down!
	ship.velocity.y += GRAVITY;
 
	// did ship collide with the singular ground object?
	if (ship.collide(ground)) {
		ship.changeAnimation("running");
		ship.velocity.y = 0;
	}
 
	// if jump
	if (keyWentDown("x") || mouseWentDown(LEFT)) {
		ship.changeAnimation("jumping");
		ship.velocity.y = -JUMP;
	}
 
	// spawn asteroid logic
	if(millis() > lastSpawnTime + spawnObstacleInterval) {
		// spawn new obstacle
		asteroid = createSprite(random(width),random(height),20,20)
 
		// give it a negative speed to go from right to left
		asteroid.velocity.x = -7;
		asteroid.addImage(asteroidIMG);
		asteroids.add(asteroid);
 
		// show bounding box
		//newSprite.debug = true;
 
		// add it to the asteroid group
		//asteroid.add(newSprite);
 
		// reset timer
		lastSpawnTime = millis();
	}
 
    //if ship hits asteroid call this function 
    ship.overlap(asteroids,hitObstacle); 
	drawSprites();
}

//provide 2 arguements
//1: big fish
//2: little fish

function hitObstacle(bernman, collectable){
       //console.log("game oveR");

       collectable.remove();
       score++;


}